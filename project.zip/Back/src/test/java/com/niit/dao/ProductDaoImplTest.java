package com.niit.dao;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.configuration.DBConfig;
import com.niit.models.Product;

import junit.framework.TestCase;

public class ProductDaoImplTest extends TestCase
{
	 ApplicationContext context=new AnnotationConfigApplicationContext(DBConfig.class,ProductDaoImpl.class);
     ProductDao productDao=(ProductDao)context.getBean("productDaoImpl");

public void testGetProduct()
{
Product product1=productDao.getProduct(1);
Product product2=productDao.getProduct(2);
Product product3=productDao.getProduct(3);
assertNotNull(product1);
assertNotNull(product2);
assertNull(product3);

double expectedPrice=1001;
double actualPrice=product1.getPrice();
assertTrue(expectedPrice!=actualPrice);

	}

}
