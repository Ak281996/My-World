package com.niit.dao;

import static org.junit.Assert.*;

import org.junit.Test;

public class ProductDaoImplTest2 {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
